#include <stdio.h>
#include <stdlib.h>

int score[50] = {
	43, 65, 51, 27, 79, 11, 56, 61, 82,  9,
	25, 36,  7, 49, 55, 63, 74, 81, 49, 37,
	40, 49, 16, 75, 87, 91, 33, 24, 58, 78,
	65, 56, 76, 67, 45, 54, 36, 63, 12, 21,
	73, 49, 51, 19, 39, 49, 68, 93, 85, 59
};

void main()
{
	int group[11] = {0};	// store student number in each group

	//Counting students and printing them
	
	printf("GROUP\t   RANGE\t STUDENT#\n");
	for (int i = 0; i < 50; i++)
	{
		int n = score[i]/10;
		group[n]++;
	}	

	for (int i = 0; i < 11; i++)
	{
		if (i == 10)
			printf("%2d\t 100 to 100\t %d\n", i+1, group[i]);
		else
			printf("%2d\t %3d to %3d\t %d\n", i+1, i*10, (i+1)*10-1, group[i]);
	}	
}
