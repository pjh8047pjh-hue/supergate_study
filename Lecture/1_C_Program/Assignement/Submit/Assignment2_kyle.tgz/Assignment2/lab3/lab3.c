#include <stdio.h>
#include <stdlib.h>

int score[50] = {
43, 65, 51, 27, 79, 11, 56, 61, 82,  9,
25, 36,  7, 49, 55, 63, 74, 81, 49, 37,
40, 49, 16, 75, 87, 91, 33, 24, 58, 78,
65, 56, 76, 67, 45, 54, 36, 63, 12, 21,
73, 49, 51, 19, 39, 49, 68, 93, 85, 59
};

void main ()
{
int group[11] = {0};  // store student number in each group 

// write code here 
// counting students and printing them 
for (int i = 0; i < sizeof(score)/sizeof(int); i++) 
	{
	//printf("%d address value : %d \n", i+1, score[i]);
	if ( score[i] >= 0 && score[i] < 10 )
		{
			group[0] ++;
		}
	else if (score[i] >= 10 && score[i] < 20)
		{
			group[1] ++;
		}
	else if (score[i] >= 20 && score[i] < 30)
		{
			group[2] ++;
		}
	else if (score[i] >= 30 && score[i] < 40)
		{
			group[3] ++;
		}
	else if (score[i] >= 40 && score[i] < 50)
		{
			group[4] ++;
		}
	else if (score[i] >= 50 && score[i] < 60)
		{
			group[5] ++;
		}
	else if (score[i] >= 60 && score[i] < 70)
		{
			group[6] ++;
		}
	else if (score[i] >= 70 && score[i] < 80)
		{
			group[7] ++;
		}
	else if (score[i] >= 80 && score[i] < 90)
		{
			group[8] ++;
		}
	else if (score[i] >= 90 && score[i] < 100)
		{
			group[9] ++;
		}
	else 
		{
			group[10] += 1;
		}
	}
		printf ( "GROUP\t\tRANGE\t\tSTUDENT#\n");
		for (int fir_i = 0; fir_i < sizeof(group)/sizeof(int); fir_i++)
		{
		if (fir_i == 10)
			{
			printf ( "%d\t%d\tto\t%d\t %d\n",fir_i+1, fir_i*10, fir_i*10, group[fir_i]);
			}
		else
			{
			printf ( "%d\t%d\tto\t%d\t %d\n",fir_i+1, fir_i*10, fir_i*10+9, group[fir_i]);
			}
		}
 }
