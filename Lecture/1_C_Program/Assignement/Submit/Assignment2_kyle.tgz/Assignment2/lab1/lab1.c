#include <stdio.h>
#include <stdlib.h>

void main ()
{

  int n = 0, i, sum = 0, cont = 1;
  printf("Enter any no: ");
  fflush(stdout);

  scanf("%d", &n);


  for (i = 1; i < n; i = i + 2)
  {
    // write code here
	printf("%d + ", i);
	sum += i;
  }
  printf("%d\n", n);
  printf("sum = %d\n", sum+n);
  getchar();
}
