#include <stdio.h>
#include <stdlib.h>

int square (int x);

void main ()
{

  int r, a;

  printf("Enter any no: ");
  fflush(stdout);
 
  scanf("%d", &a);


  // function call for squaring a number 
  // store the return value to variable r;

  // write code here
  r = square(a);
  printf("Square is %d\n", r);
  getchar();
}

// 
int square (int x) {
  // write code
  int result = 0;
  result = x*x;
  return result;
}  

