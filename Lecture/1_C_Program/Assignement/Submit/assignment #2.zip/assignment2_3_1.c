#include <stdio.h>
#include <stdlib.h>

int score[50] = {
43, 65, 51, 27, 79, 11, 56, 61, 82,  9,
25, 36,  7, 49, 55, 63, 74, 81, 49, 37,
40, 49, 16, 75, 87, 91, 33, 24, 58, 78,
65, 56, 76, 67, 45, 54, 36, 63, 12, 21,
73, 49, 51, 19, 39, 49, 68, 93, 85, 59
};

void main()
{
	int group[11] = {0};  // store student number in each group 
	int i=0,n=0;

	for(i=0; i<50; i++){
		if(score[i]>=100)
		group[10]++;

		else if(score[i]>=90)
		group[9]++;

		else if(score[i]>=80)
		group[8]++;

		else if(score[i]>=70)
		group[7]++;

		else if(score[i]>=60)
		group[6]++;

		else if(score[i]>=50)
		group[5]++;

		else if(score[i]>=40)
		group[4]++;

		else if(score[i]>=30)
		group[3]++;

		else if(score[i]>=20)
		group[2]++;

		else if(score[i]>=10)
		group[1]++;

		else
		group[0]++;

	}
	printf("GROUP\t\tRANGE\t\tSTUDENT\n");
	for(n=0; n<11; n++){
		if(n==10){
		printf(" %2d\t     %3d to %3d\t\t%4d\n", n+1,100,100, group[n]);
		break;}
	printf(" %2d\t     %3d to %3d\t\t%4d\n", n+1, n*10,(n*10)+9, group[n]);
	}
}
