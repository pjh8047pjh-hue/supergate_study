#include <stdio.h>
#include <stdlib.h>

int square (int x);

void main ()
{
	int r,a;
	printf("Enter any no: ");
	fflush(stdout);

	scanf("%d", &a);

	r = square(a);

	printf("Square is %d",r);
	getchar ();
}

int square (int x) 
{
	int z;
	z = x*x;
	return z;
}  

